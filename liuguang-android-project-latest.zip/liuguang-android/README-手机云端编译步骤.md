# 璃光 Android 项目

## 用 GitHub Actions 编译 APK
1. 在 GitHub 新建仓库 `liuguang-android`。
2. 解压本 ZIP，把里面的所有文件和文件夹上传到仓库根目录。务必包含隐藏目录 `.github/workflows`。
3. 打开仓库的 **Actions** 页面，选择 **Build Liuguang Android APK**。
4. 点击 **Run workflow**，再点击绿色按钮确认。
5. 等待任务成功后，打开本次运行页面底部的 **Artifacts**，下载 `liuguang-debug-apk`。
6. 解压下载的 artifact，得到 `app-debug.apk`，传到 OPPO 手机上安装。

本项目使用 Android WebView 加载本地 assets，不需要网络权限，应用界面资源随 APK 打包。
